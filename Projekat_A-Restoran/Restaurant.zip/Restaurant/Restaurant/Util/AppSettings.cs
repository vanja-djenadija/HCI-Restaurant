﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Util
{
    public static class AppSettings
    {
        public static string AppLanguage
        {
            get;
            set;
        } = "English";
    }
}
